package twogtwoj.whereishere.web.test.Team;

import lombok.Data;

@Data
public class LoginForm {


    private String LoginId;


    private String LoginPw;

    private Role role;
}
