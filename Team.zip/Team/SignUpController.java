package twogtwoj.whereishere.web.test.Team;

import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import twogtwoj.whereishere.domain.Company;
import twogtwoj.whereishere.domain.Member;
import twogtwoj.whereishere.file.FileStore;
import twogtwoj.whereishere.repository.MemberRepository;
import twogtwoj.whereishere.service.CompanyService;
import twogtwoj.whereishere.service.MemberService;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@Controller
public class SignUpController {

    private final MemberService memberService;
    private final BCryptPasswordEncoder passwordEncoder;

    private final CompanyService companyService;

    private final FileStore fileStore;


    // 회원 가입 메인 페이지(개인/기업 구분 페이지)
    @GetMapping("/login/SignUp")
    public String signUpMain(){
        return "/login/SignUp";
    }


    // 회원 가입(개인)
    @GetMapping("/login/SignUpMember")
    public String signUpMemberForm(Model model) {
        model.addAttribute("member", new Member());
        return "/login/SignUpMember";
    }

    @PostMapping("/login/SignUpMember")
    public String signUpMember(@RequestParam String memberLoginId, @RequestParam String memberLoginPw,
                             @RequestParam String memberName, @RequestParam String memberBirthday) {

        int year = Integer.parseInt(memberBirthday.substring(0, 4));
        int month = Integer.parseInt(memberBirthday.substring(4, 6));
        int day = Integer.parseInt(memberBirthday.substring(6, 8));

       memberService.save(new Member(memberLoginId,memberLoginPw,memberName, LocalDate.of(year,month,day), Role.ROLE_MEMBER));
       return "redirect:/"; // 로그인 페이지(메인 index)로 넘어감
    }

    // 회원 가입(기업)
    @GetMapping("/login/SignUpCompany")
    public String saveCompanyForm(){
    return "/login/SignUpCompany";
     }

     @PostMapping("/login/SignUpCompany")
    public String saveCompany(@RequestParam String companyLoginId, @RequestParam String companyLoginPw,
                              @RequestParam Long companyBusinessId, @RequestParam String companyName,
                              @RequestParam String companyCategory, @RequestParam String companyAddress,
                              @RequestParam MultipartFile companyImg, @RequestParam String companyIntroduction) throws IOException {

        String companyImgString = UUID.randomUUID() + ".png";
        companyImg.transferTo(new File(fileStore.getFullPath(companyImgString)));
       companyService.save(new Company(companyLoginId,companyLoginPw,companyBusinessId,companyName,companyImgString,
                companyIntroduction,companyCategory,companyAddress, Role.ROLE_COMPANY));

        return "redirect:/"; // 로그인 페이지(메인 index)로 넘어감
    }
}