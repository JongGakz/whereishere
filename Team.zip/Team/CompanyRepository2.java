package twogtwoj.whereishere.web.test.Team;

import org.springframework.data.repository.CrudRepository;
import twogtwoj.whereishere.domain.Company;
import twogtwoj.whereishere.domain.Member;

import java.util.Optional;

public interface CompanyRepository2 extends CrudRepository<Company, Long> {

    Optional<Company> findByCompanyLoginId(String companyLoginId);
}
