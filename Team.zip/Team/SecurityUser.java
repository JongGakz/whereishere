package twogtwoj.whereishere.web.test.Team;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import twogtwoj.whereishere.domain.Member;

@Slf4j
@Getter
@Setter
public class SecurityUser extends User {

    private Member member;

    private LoginForm loginForm;

//    public SecurityUser(LoginForm loginForm){
//        super(loginForm.getLoginId(), loginForm.getLoginPw(), AuthorityUtils.createAuthorityList(loginForm.getRole().toString()));
//        this.loginForm = loginForm;
//    }

    public SecurityUser(Member member) {
        super(member.getMemberLoginId(), member.getMemberLoginPw(), AuthorityUtils.createAuthorityList(member.getMemberRole().toString()));

        log.info("SecurityUser member.username = {}", member.getMemberLoginId());
        log.info("SecurityUser member.password = {}", member.getMemberLoginPw());
        log.info("SecurityUser member.role = {}", member.getMemberRole().toString());

        this.member = member;
    }


    //계정이 만료되지 않았는지 리턴 (true: 만료안됨)
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    //계정이 잠겨있는지 않았는지 리턴. (true:잠기지 않음)
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    //비밀번호가 마료되지 않았는지 리턴한다. (true:만료안됨)
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    //계정이 활성화(사용가능)인지 리턴 (true:활성화)
    @Override
    public boolean isEnabled() {
        return true;
    }
}
