package twogtwoj.whereishere.web.test.Team;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import twogtwoj.whereishere.domain.Company;
import twogtwoj.whereishere.domain.Member;
import twogtwoj.whereishere.repository.CompanyRepository;

import java.util.Optional;

@Slf4j
@Component
@Service
@RequiredArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService {


    private final MemberRepository2 memberRepository;

    private final CompanyRepository2 companyRepository;

//    @Override
//    public UserDetails loadUserByUsername(String loginId) throws UsernameNotFoundException {
//        Optional<Member> findMember = memberRepository.findByMemberLoginId(loginId);
//        Optional<Company> findCompany = companyRepository.findByCompanyLoginId(loginId);
//
//        if (findMember.isPresent()) {
//            Member member = findMember.get();
//            return new SecurityUser(member.getMemberLoginId(), member.getMemberLoginPw(), member.getMemberRole());
//        } else if (findCompany.isPresent()) {
//            Company company = findCompany.get();
//            return new SecurityUser(company.getEmail(), company.getPassword());
//        } else {
//            throw new UsernameNotFoundException("User not found with login ID: " + loginId);
//        }
//    }


    @Override
    public UserDetails loadUserByUsername(String memberLoginId) throws UsernameNotFoundException {
        Optional<Member> findMember = memberRepository.findByMemberLoginId(memberLoginId);
        if (!findMember.isPresent()) throw new UsernameNotFoundException("존재하지 않는 username 입니다.");

        return new SecurityUser(findMember.get());
    }
}