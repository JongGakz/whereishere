package twogtwoj.whereishere.web.test.Team;

import lombok.RequiredArgsConstructor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@RequiredArgsConstructor
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final UserDetailsServiceImpl userDetailsService;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        //http.csrf().disable();
        http.authorizeRequests()
                .antMatchers("/","/login/SignUp","/login/SignUpCompany","/login/SignUpMember", "/home/**").permitAll()
                .antMatchers("/home","/home/**").authenticated(); // 일반사용자 접근 가능
                //.antMatchers("/home/**").hasAnyRole("MEMBER"); // 매니저, 관리자 접근 가능
//                .antMatchers("/admin/**").hasRole("ADMIN"); // 관리자만 접근 가능

        http.formLogin()
                .loginPage("/")
                .loginProcessingUrl("/")
                .usernameParameter("loginId")
                .passwordParameter("loginPw")
                .defaultSuccessUrl("/home/home", true)
                .failureUrl("/");
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService);
    }
}