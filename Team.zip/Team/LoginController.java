package twogtwoj.whereishere.web.test.Team;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class LoginController {

    private final UserDetailsServiceImpl userDetailsService;

    @GetMapping("/")
    public String loginGet(@ModelAttribute("LoginForm") LoginForm LoginForm){
    return "/index";
    }

    @GetMapping("/home/home")
    public String homeGO(){
        return "home/home";
    }
}
